/**
 * Example problem with existing solution and passing test.
 * See problem 0 in the spec file for the assertion
 * @returns {string}
 */
exports.example = () => 'hello world';

exports.stripPrivateProperties = (arrAttr, arrObject) => {

    // 一个新的数组
    let ret = arrObject.slice();

    ret.forEach((item) => {
        arrAttr.forEach((item1) => {
            if(item.hasOwnProperty(item1) ){
                delete item[item1];
            }
        })
    })

    return ret;
    
};
exports.excludeByProperty = (delkey, arrObject) => {
    // 一个新的数组
    let ret = arrObject.slice();

    return ret.reduce((arr, item, index ) => {
       
        if(!item.hasOwnProperty(delkey)){
                       
            arr.push(item);
        }

        return arr;
        
    },[])
};
exports.sumDeep = (arrObject, a = 'objects', b = 'val') => {

    return arrObject.map((item) => {
        item[a] = item[a].reduce((num, item1) => {
            return num += item1[b];
        }, 0)
        return item;
    })

};
exports.applyStatusColor = (obj, arr, a = 'color', b='status') => {

    let ret = arr.reduce((arr,item) => {
        Object.entries(obj).forEach((item1) => {
            if(item1[1].indexOf(item[b]) > -1){
                item[a] = item1[0];
                arr.push(item);
            }
            

        })
        
        return arr;
    }, [])
    return ret;

};
exports.createGreeting = (fn, str) => {

    return (name) => {
        return fn(str, name);
    };
};
exports.setDefaults = (baseObj) => {

    
    return (obj) => {
        let ret = {};

        Object.keys(baseObj).forEach((item) => {
            if(!obj.hasOwnProperty(item)){
                ret = baseObj;
            }
        })
       
        return Object.assign(obj, ret);
    }
};
exports.fetchUserByNameAndUsersCompany = async (str, service) => {

    let allUser = await service.fetchUsers();
    let status = await service.fetchStatus();
  
    let company = null;

    let user = allUser.find(({ name }) => name === str) || {};


    if(user.companyId){
        company = await service.fetchCompanyById(user.companyId);
    }
    
    let ret = {
        company,
        status,
        user,
    }
    return ret;
};
